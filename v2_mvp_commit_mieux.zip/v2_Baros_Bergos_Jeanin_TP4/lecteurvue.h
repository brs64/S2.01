#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include "classes_modele.h"
#include <QMainWindow>



QT_BEGIN_NAMESPACE
namespace Ui { class lecteurVue; }
QT_END_NAMESPACE

class ImgPres;
class ImgDsDiapoPres;
class DiapoPres;
class lecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    explicit lecteurVue(QWidget *parent = nullptr); // Constructeur par défaut
    ~lecteurVue(); // Destructeur

    void setUi(Ui::lecteurVue*);
    Ui::lecteurVue* getUi();

    void setImgCourante(ImgPres*);
    ImgPres* getImgCourante();

    void setUi(ImgDsDiapoPres*);
    ImgDsDiapoPres* getImgDsDiapo();

    void setUi(DiapoPres *);
    DiapoPres* getDiapo();


    void majInfosImgDsDiapo();
    void majInfosDiapo();
    //void majMode();



public slots :
    // Déclaration des différents slots
    void demanderFiltres();
    void demanderVitesseDefilement();
    void demanderChargerDiaporama();
    void demanderQuitter();
    void demanderAProposDe();
    void demanderPrecedent();
    void demanderSuivant();
    void demanderPause();
    void demanderChangerModeDefilement();

private:
    Ui::lecteurVue *ui; // Interface utilisateur
    ImgPres *_imgCourante;
    ImgDsDiapoPres *_imgDsDiapoCourante;
    DiapoPres *_DiapoCourant;

};






































#endif // LECTEURVUE_H
