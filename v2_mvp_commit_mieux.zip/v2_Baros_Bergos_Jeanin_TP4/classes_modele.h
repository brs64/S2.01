#ifndef CLASSES_MODELE_H
#define CLASSES_MODELE_H
#include <vector>
#include <iostream>
using namespace std;

class ImgMdl {
public:
    string titre;              // intitulé de l'image
    string categorie;          // catégorie de l'image (personne, animal, objet)
    string chemin;

    ImgMdl(string="", string="", string="");
    ImgMdl(const ImgMdl&);
    ~ImgMdl();

    string getTitre() const;
    void setTitre(string);

    string getCategorie() const;
    void setCategorie(string);

    string getChemin() const;
    void setChemin(string);

    void afficher() const;
};

typedef vector<ImgMdl> Images;


class ImgDsDiapoMdl : public ImgMdl {
public:
    unsigned int pos;  // rang de l'image dans le tableau d'images (vector<Images>)
        // = ordre de chargement initial des images dans la table des images
    unsigned int rang;  // rang de l'image dans le diaporama
        // = ordre d'affichage choisi par l'utilisateur lors de la création du diaporama

    ImgDsDiapoMdl(const ImgMdl& = ImgMdl(), unsigned int=0,unsigned int=0);
    ImgDsDiapoMdl(const ImgDsDiapoMdl&);
    ~ImgDsDiapoMdl();
    unsigned int getPos() const;
    void setPos(unsigned int);
    unsigned int getRang() const;
    void setRang(unsigned int);

    void chargerImgDsDiapo();
};

typedef vector<ImgDsDiapoMdl> ImagesDansDiaporama;


class DiapoMdl {
public:
    string titre; // titre du diaporama
    unsigned int vitesseDefilement; // vitesse de défilement des images du diaporama
    ImagesDansDiaporama localisationImages; // images du diaporama
    unsigned int posImageCourante;

    DiapoMdl(const ImagesDansDiaporama& = ImagesDansDiaporama(), string="Diaporama par defaut",unsigned int=2, unsigned int=0);
    DiapoMdl(const DiapoMdl&);
    ~DiapoMdl();

    string getTitre() const;
    void changerTitre(string);
    void setTitre(string);

    void chargerDiapo();

    unsigned int getVitesseDefilement() const;
    void setVitesseDefilement(unsigned int);
    unsigned int getPosImageCourante() const;
    void setPosImageCourante(unsigned int);
    ImagesDansDiaporama getLocalisationImages() const;
    void setLocalisationImages(ImagesDansDiaporama&);

    ImgDsDiapoMdl getImageCourante() const;
    void avancer(); // incrémente pPosImageCourante, modulo nbImages(pDiaporama)
    void reculer(); // décrémente pPosImageCourante, modulo nbImages(pDiaporama)
    unsigned int nbImages() const; // affiche la taille du diaporama pDiaporama
    void triCroissantRang ();
    /* Tri du diaporama pDiaporama par ordre croissant de *rang* des ses images
   A garder aussi lors de l'implémentation de la BD */
    void pushBackImage(const ImgDsDiapoMdl&);
    void clear();
};

typedef vector<DiapoMdl> Diaporamas;
















































#endif // CLASSES_MODELE_H
