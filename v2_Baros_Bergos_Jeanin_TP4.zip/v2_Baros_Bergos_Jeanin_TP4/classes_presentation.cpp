#include "classes_presentation.h"

void ImgPres::demandeChangerTitre(string s) {
    _modele->setTitre(s);
}

void ImgPres::demandeChangerCat(string s) {
    _modele->setCategorie(s);
}

void ImgPres::demandeChangerChemin(string s) {
    _modele->setChemin(s);
}








































void DiapoPres::demandeChangerTitre(string) {

}

void DiapoPres::demandeChangerVitesse(unsigned int) {

}

void DiapoPres::demandeChangerlocImgs(ImagesDansDiaporama) {

}

void DiapoPres::demandeChangerPosImgCourate(unsigned int) {

}


// ###############################################################




