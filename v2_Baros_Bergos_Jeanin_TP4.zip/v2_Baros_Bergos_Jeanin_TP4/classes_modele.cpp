#include "classes_modele.h"

string ImgMdl::getTitre() const {
    return (*this).titre;
}
void setTitre(string s) {
    (*this).titre = s;
}

string ImgMdl::getCategorie() const{
    return (*this).categorie;
}
void setCategorie(string s){
    (*this).categorie = s;
}

string ImgMdl::getChemin() const{
    return (*this).chemin;
}
void setChemin(string s){
    (*this).chemin = s;
}

void ImgMdl::afficher() const {

}
