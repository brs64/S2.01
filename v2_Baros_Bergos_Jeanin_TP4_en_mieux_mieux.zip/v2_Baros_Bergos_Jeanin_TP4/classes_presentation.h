#ifndef CLASSES_PRESENTATION_H
#define CLASSES_PRESENTATION_H
#include "classes_modele.h"


// sert d'intermédiaire entre vue et présentaiton
//=> gère les mises à jour des infos (présentation)
//=> transmet les infos que la vue doit afficher

class lecteurVue;

class ImgPres {

    public:
    void demandeChangerTitre(string);
    void demandeChangerCat(string);
    void demandeChangerChemin(string);



    private:
        ImgMdl *_modele;
        lecteurVue *_lecteur;

    };


class ImgDsDiapoPres {

    public:
        void demandeChangerPos(string);
        void demandeChangerRang(string);
        void demanderChargerImg();




    private:
        ImgDsDiapoMdl *_modele;
        lecteurVue *_lecteur;

};


class DiapoPres {

    public:
        DiapoPres();
        void demanderChargerDiapo();
        void demandeChangerTitre(string);
        void demandeChangerVitesse(unsigned int);
        void demandeChangerlocImgs(ImagesDansDiaporama);
        void demandeChangerPosImgCourate(unsigned int);




    private:
        DiapoMdl *_modele;
        lecteurVue *_lecteur;

    };


class LecteurPres {
    public:
        LecteurPres();
        void changerMode();
        bool verifAuto();


    private:
        LecteurMdl *_modele;
        lecteurVue *_lecteur;


};






    #endif // CLASSES_PRESENTATION_H
